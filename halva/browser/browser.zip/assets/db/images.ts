const images = [
  './assets/images/mereng.jpg',
  './assets/images/tri-shokolada.jpg',
  './assets/images/krasniy-barhat.JPG',
  './assets/images/medovik.JPG'
]

export default images